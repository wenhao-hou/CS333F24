from flask import Flask, render_template, request, redirect, url_for
from gbmodel.model_sqlite3 import SQLiteModel
from flask import Flask
import logging
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)




app = Flask(__name__)
model = SQLiteModel('path_to_your_database.db')  # Make sure to provide the correct path

@app.route('/')
def index():
    logger.info('Visited the index page')


    # The landing page might show a form to create a new entry
    return render_template('index.html')

@app.route('/entries', methods=['GET'])
def view_entries():
    # Retrieve all entries using the model
    logger.info('Retrieving entries')

    entries = model.select()
    return render_template('view_entries.html', entries=entries)

@app.route('/create', methods=['GET', 'POST'])
def create_entry():
    if request.method == 'POST':
        logger.info('Received POST request for new entry creation')

        # Get data from form
        name = request.form.get('name')
        description = request.form.get('description')
        street_address = request.form.get('street_address')
        type_of_service = request.form.get('type_of_service')
        phone_number = request.form.get('phone_number')
        hours_of_operation = request.form.get('hours_of_operation')
        reviews = request.form.get('reviews')
        
        # Insert the new entry into the database
        success=model.insert(name, description, street_address, type_of_service, phone_number, hours_of_operation, reviews)
        if success:
            logger.info('New entry created successfully')
        else:
            logger.error('Failed to create new entry')
        # Redirect to the view entries page
        return redirect(url_for('view_entries'))
    else:
        logger.info('Visited create entry page')
        # If method is GET, just render the create entry form
        return render_template('create_entry.html')
    # If method is GET, just render the create entry form

if __name__ == '__main__':
        app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 8080)))
        logger.info(f'Starting Flask app on port {port}')


